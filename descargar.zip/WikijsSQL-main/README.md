<em> #  WikijsSQL </em># 
Archivos de configuracion y docker compose para montar el servicio WIKI.
Materia de Laboratorio de SO y Redes.
Profesor: Daniel Buaon
Tema 5

Pasos: 
1) Descargar los archivos desde Github
2) Darle permiso de ejecucion al script: ``` chmod +x instalador.sh ```
3) Ejecutar el script de instalacion: ``` ./instalador.sh ```
4) Cerrar la sesion y volver a conectarse
5) Ejecutar el docker-compose.yml: ``` docker-compose up ``` o ``` docker-compose up -d ``` para usarlo en segundo plano
6) Ingresar a la ip publica desde el navegador
